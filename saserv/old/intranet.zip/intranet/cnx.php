<?php
  //define ("salto","\n<br>\n");
  
  
  $conexion=mysql_connect("localhost","manager1_admin","mcode2016");
  $baseDeDatos=mysql_select_db("manager1_code",$conexion);
  
  //$conexion=mysql_connect("localhost","systems3_admin","hdwtnkue456");
  //$baseDeDatos=mysql_select_db("systems3_admin",$conexion);
?>
